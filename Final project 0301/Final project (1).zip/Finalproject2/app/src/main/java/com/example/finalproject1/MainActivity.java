package com.example.finalproject1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity{

    TextView name, HP;
    ImageView weaponIMG, monsterIMG;
    Monster monster;

    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference myRef;
    FirebaseUser account;

    Gamer gamer;

    private View.OnClickListener attackOnClickListener = v -> Attack(v);
    //private View.OnClickListener shopOnClickListener = v -> shop();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainapp_page);

        name = findViewById(R.id.monsterName);
        HP = findViewById(R.id.monsterHP);
        weaponIMG = findViewById(R.id.weapon);
        monsterIMG = findViewById(R.id.monsterIMG);

        weaponIMG.setOnClickListener(attackOnClickListener);
        monsterIMG.setOnClickListener(attackOnClickListener);

        monster = new Monster();
        monster.createSlime(1, 1, 60, 0.5, 20, new Weapon("sword", 5, 20),
                "small", "water");

        name.setText("level "+monster.getLevel()+" "+monster.getName());
        HP.setText("HP = "+monster.getHp());

        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Users");
        account = mAuth.getCurrentUser();
        myRef.child(account.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                gamer = new Gamer(dataSnapshot.child("email").getValue(String.class),
                        dataSnapshot.child("password").getValue(String.class),
                        dataSnapshot.child("name").getValue(String.class),
                        dataSnapshot.child("weapon").getValue((Weapon.class)));
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });
    }

    public void Attack(View view) {
        monster.onHit(gamer.getWeapon().getDamage());
        gamer.getWeapon().onAttack();

        HP.setText("HP = "+monster.getHp());

        ObjectAnimator animation = ObjectAnimator.ofFloat(weaponIMG, "translationY", 0f ,-500f);
        animation.setDuration(500);
        animation.start();

        animation = ObjectAnimator.ofFloat(weaponIMG, "translationY", -500f, 0);
        animation.setDuration(500);
        animation.start();

        animation = ObjectAnimator.ofFloat(monsterIMG, "translationX", 0f, 100f);
        animation.setDuration(333);
        animation.start();

        animation = ObjectAnimator.ofFloat(monsterIMG, "translationX", 100f, -100f);
        animation.setDuration(333);
        animation.start();

        animation = ObjectAnimator.ofFloat(monsterIMG, "translationX", -100f, 0f);
        animation.setDuration(333);
        animation.start();

        if(monster.death()) {
            if(Math.random() > monster.getDropChance()){
                gamer.setWeapon(monster.getWeaponType());
            }
            Toast.makeText(this, gamer.getWeapon().toString(), Toast.LENGTH_LONG).show();
            FirebaseDatabase.getInstance().getReference("Users")
                    .child(account.getUid()).setValue(gamer);
            Intent intent = new Intent(view.getContext(), WinActivity.class);
            view.getContext().startActivity(intent);
        }

    }

    public void shop(){

    }
}