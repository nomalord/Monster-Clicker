package com.example.finalproject1;

public class Gamer extends User{
    private String stats;

    private int level; //the player's level
    private int stage; //the stage the player is on

    private int gold; //how much gold the player has
    private Weapon weapon;

    public Gamer(String email, String password, String name, String stats, int level, int stage, int gold, Weapon weapon) {
        super(email, password, name);
        this.stats = stats;
        this.level = level;
        this.stage = stage;
        this.gold = gold;
        this.weapon = weapon;
    }

    public Gamer(String email, String password, String name, Weapon weapon) {
        super(email, password, name);
        this.level = 1;
        this.stage = 1;
        this.gold = 0;
        this.weapon = weapon;
    }

    public String getStats() {
        return stats;
    }

    public void setStats(String stats) {
        this.stats = stats;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getStage() {
        return stage;
    }

    public void setStage(int stage) {
        this.stage = stage;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }

    @Override
    public String toString() {
        return "Gamer{" +
                "stats='" + stats + '\'' +
                ", level=" + level +
                ", stage=" + stage +
                ", gold=" + gold +
                ", weapon=" + weapon +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
