package com.example.finalproject1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity implements View.OnClickListener{
    Button app, dev;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_page);

        app = findViewById(R.id.app);
        dev = findViewById(R.id.aboutDev);

        app.setOnClickListener(this);
        dev.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.app:
                intent = new Intent(view.getContext(), LoginActivity.class);
                this.startActivity(intent);
                break;
            case R.id.aboutDev:
                intent = new Intent(view.getContext(), AboutActivity.class);
                this.startActivity(intent);
        }

    }
}
