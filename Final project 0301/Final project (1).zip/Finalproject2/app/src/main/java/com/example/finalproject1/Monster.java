package com.example.finalproject1;

import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Monster extends AppCompatActivity {


    protected String name, size, type;
    protected int level; //the monsters' level
    protected int gold; //gold gained from killing the monster
    protected int time; // how much time you have to defeat the monster
    protected int hp; //monster hit points
    protected Boolean isMagical; //magical monsters have more stats, are stronger but drop better gear

    protected double dropChance;

    Weapon WeaponType;

    //protected String[] listSize = new String[]{"small", "medium", "large", "enormous"};
    //protected String[] listType = new String[]{"fire", "water", "wind", "earth"};

    public Monster(String name, int level, int gold, int time, double dropChance, int hp, String weaponName,
                   String size, String type) {
        this.name = name;
        this.level = level;
        this.gold = gold;
        this.time = time;
        this.dropChance = dropChance;
        this.hp = hp;
        this.size = size;
        this.type = type;

        WeaponType = new Weapon(weaponName, 0, 0);
        isMagical = false;
    }

    public Monster(String name, int level, int gold, int hp) {
        this.name = name;
        this.level = level;
        this.gold = gold;
        this.hp = hp;
    }
    public Monster(){
        this.name = null;
        this.level = 0;
        this.gold = 0;
        this.time = 0;
        this.dropChance = 0;
        this.hp = 0;
        this.size = null;
        this.type = null;

        WeaponType = null;
        isMagical = null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public double getDropChance() {
        return dropChance;
    }

    public void setDropChance(double dropChance) {
        this.dropChance = dropChance;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public Boolean getMagical() {
        return isMagical;
    }

    public void setMagical(Boolean magical) {
        isMagical = magical;
    }

    public Weapon getWeaponType() {
        return WeaponType;
    }

    public void setWeaponType(Weapon weaponType) {
        WeaponType = weaponType;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Monster{" +
                "name='" + name + '\'' +
                ", size='" + size + '\'' +
                ", type='" + type + '\'' +
                ", level=" + level +
                ", gold=" + gold +
                ", time=" + time +
                ", hp=" + hp +
                ", isMagical=" + isMagical +
                ", dropChance=" + dropChance +
                ", WeaponType=" + WeaponType +
                '}';
    }
    public void onHit(int hit){
        setHp(this.hp - hit);
    }
    public Boolean death(){
        if(this.hp <= 0)
            return true;
        return false;
    }


    public void createSlime(int level, int gold, int time, double dropChance, int hp, Weapon weapon,
                   String size, String type) {
        this.name = "slime";
        this.level = level;
        this.gold = gold;
        this.time = time;
        this.dropChance = dropChance;
        this.hp = hp;
        this.size = size;
        this.type = type;

        this.WeaponType = weapon;
        this.isMagical = false;
    }

    public void createGoblin(int level, int gold, int time, double dropChance, int hp, Weapon weapon,
                            String size, String type) {
        this.name = "goblin";
        this.level = level;
        this.gold = gold;
        this.time = time;
        this.dropChance = dropChance;
        this.hp = hp;
        this.size = size;
        this.type = type;

        this.WeaponType = weapon;
        this.isMagical = false;
    }

    public void createOgre(int level, int gold, int time, double dropChance, int hp, Weapon weapon,
                             String size, String type) {
        this.name = "ogre";
        this.level = level;
        this.gold = gold;
        this.time = time;
        this.dropChance = dropChance;
        this.hp = hp;
        this.size = size;
        this.type = type;

        this.WeaponType = weapon;
        this.isMagical = false;
    }
}
