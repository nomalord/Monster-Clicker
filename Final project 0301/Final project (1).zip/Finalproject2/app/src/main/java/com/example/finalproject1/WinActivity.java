package com.example.finalproject1;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class WinActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.win_page);
    }
}
