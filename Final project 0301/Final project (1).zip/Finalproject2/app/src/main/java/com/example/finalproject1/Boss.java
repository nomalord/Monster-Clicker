package com.example.finalproject1;

public class Boss extends Monster{
    //private String[] difficultyList = new String[]{"easy", "medium", "hard"};
    private String difficulty;
    private int bossCoins;

    public Boss(String name, int level, int gold, int time, double dropChance, int hp, String weaponName, String size,
                String type, String difficulty, int bossCoins) {
        super(name, level, gold, time, dropChance, hp, weaponName, size, type);
        this.difficulty = difficulty;
        this.bossCoins = bossCoins;
    }

    public void setDifficulty(){
        switch (this.difficulty){
            case "easy":
                super.setLevel(level + 2);
                super.setGold(gold + 2);
                bossCoins = 2;
                break;
            case "medium":
                super.setLevel(level + 5);
                super.setGold(gold + 5);
                bossCoins = 5;
            case "hard":
                super.setLevel(level + 10);
                super.setGold(gold + 10);
                bossCoins = 10;
        }
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public int getBossCoins() {
        return bossCoins;
    }

    public void setBossCoins(int bossCoins) {
        this.bossCoins = bossCoins;
    }

    @Override
    public String toString() {
        return "Boss{" +
                "difficulty='" + difficulty + '\'' +
                ", bossCoins=" + bossCoins +
                ", name='" + name + '\'' +
                ", size='" + size + '\'' +
                ", type='" + type + '\'' +
                ", level=" + level +
                ", gold=" + gold +
                ", time=" + time +
                ", hp=" + hp +
                ", isMagical=" + isMagical +
                ", dropChance=" + dropChance +
                ", WeaponType=" + WeaponType +
                '}';
    }
    public void createWitch(int level, int gold, int time, double dropChance, int hp, Weapon weapon,
                             String size, String type) {
        this.name = "witch";
        this.level = level;
        this.gold = gold;
        this.time = time;
        this.dropChance = dropChance;
        this.hp = hp;
        this.size = size;
        this.type = type;

        this.WeaponType = weapon;
        this.isMagical = false;
    }

    public void createGoblin(int level, int gold, int time, double dropChance, int hp, Weapon weapon,
                             String size, String type) {
        this.name = "dragon";
        this.level = level;
        this.gold = gold;
        this.time = time;
        this.dropChance = dropChance;
        this.hp = hp;
        this.size = size;
        this.type = type;

        this.WeaponType = weapon;
        this.isMagical = false;
    }
}
