package com.example.finalproject1;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    FirebaseAuth mAuth;
    FirebaseDatabase database;
    DatabaseReference myRef;
    FirebaseUser account;

    EditText logEmail, logPassword;
    Button logBtn ,regOpen, guestLogin;
    Intent intent;

    String temp;

    Weapon weapon = new Weapon();

    User user = new User("", "", "");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);

        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Users");

        logEmail = findViewById(R.id.logEmail);
        logPassword = findViewById(R.id.logPassword);
        logBtn = findViewById(R.id.logBtn);
        regOpen = findViewById(R.id.regOpen);
        guestLogin = findViewById(R.id.guestLogin);

        logBtn.setOnClickListener(this);
        regOpen.setOnClickListener(this);
        guestLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.logBtn:
                if(logEmail.getText().toString().isEmpty() || logPassword.getText().toString().isEmpty())
                    Toast.makeText(LoginActivity.this, "Please fill out all the required parameters",
                            Toast.LENGTH_SHORT).show();
                else{
                    mAuth.signInWithEmailAndPassword(logEmail.getText().toString(), logPassword.getText().toString())
                            .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        // Sign in success, update UI with the signed-in user's information
                                        Log.d(TAG, "signInWithEmail:success");
                                        account = mAuth.getCurrentUser();
                                        updateUI(account);
                                        myRef.child(account.getUid()).addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot) {
                                                temp = dataSnapshot.child("name").getValue(String.class);
                                            }

                                            @Override
                                            public void onCancelled(DatabaseError error) {
                                            }
                                        });
                                        user = new Gamer(logEmail.getText().toString(),
                                                logPassword.getText().toString(),
                                                temp,
                                                weapon);
                                        FirebaseDatabase.getInstance().getReference("Users")
                                                .child(account.getUid()).setValue(user);

                                        intent = new Intent(view.getContext(), MainActivity.class);
                                        view.getContext().startActivity(intent);

                                    } else {
                                        // If sign in fails, display a message to the user.
                                        Log.w(TAG, "signInWithEmail:failure", task.getException());
                                        Toast.makeText(LoginActivity.this, "Authentication failed.",
                                                Toast.LENGTH_SHORT).show();
                                        updateUI(null);
                                    }
                                }
                            });
                }
                break;
            case R.id.regOpen:
                intent = new Intent(view.getContext(), RegisterActivity.class);
                view.getContext().startActivity(intent);
                break;
            case R.id.guestLogin:
                break;
        }

    }
    public void updateUI(FirebaseUser account) {

        if (account != null) {
            Toast.makeText(this, "You Have Logged in successfully", Toast.LENGTH_LONG).show();

        } else {
            Toast.makeText(this, "You Didn't Login successfully", Toast.LENGTH_LONG).show();
        }
    }
}
