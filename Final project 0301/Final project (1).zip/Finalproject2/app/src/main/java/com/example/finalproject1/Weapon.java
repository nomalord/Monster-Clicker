package com.example.finalproject1;

public class Weapon {

    private String name; //weapon's name
    private int damage; //based on character damage
    private int breakingPoint; //number of attacks before weapon breaks

    //private String[] weaponList = new String[]{"fists","Sword", "Hammer", "Mace", "Dagger", "Rapier"};

    public Weapon(String name, int damage, int breakingPoint) {
        this.name = name;
        this.damage = damage;
        this.breakingPoint = breakingPoint;
    }

    public Weapon() {
        this.name = "fists";
        this.damage = 1;
        this.breakingPoint = -1;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getBreakingPoint() {
        return breakingPoint;
    }

    public void setBreakingPoint(int breakingPoint) {
        this.breakingPoint = breakingPoint;
    }


    @Override
    public String toString() {
        return "Weapon{" +
                "name='" + name + '\'' +
                ", damage=" + damage +
                ", breakingPoint=" + breakingPoint +
                '}';
    }

    public void onAttack(){
        this.breakingPoint--;
        if(this.breakingPoint == 0){
            this.name = "fists";
            this.damage = 1;
            this.breakingPoint = -1;
        }
    }
}
